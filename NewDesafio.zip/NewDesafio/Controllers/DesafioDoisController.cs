﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using NewDesafio.Services;
using Newtonsoft.Json;





// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NewDesafio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DesafioDoisController : ControllerBase
    {
        // GET: api/<DesafioUmController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<DesafioUmController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<DesafioUmController>
        [HttpPost]        
        public void Post(Object json)
        {            
            try
            {
                string _json = json.ToString();
                dynamic dobj = JsonConvert.DeserializeObject<dynamic>(_json);
                string _brackets = dobj["brackets"].Value;
                bool _expeted = dobj["expeted"].Value;
                                
                new DesafioBackend().Desafio02(_brackets, _expeted);

            }
            catch (Exception)
            {

                throw;
            }
        }

        // PUT api/<DesafioUmController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<DesafioUmController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
