﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using NewDesafio.Services;
using Newtonsoft.Json;





// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NewDesafio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DesafioTresController : ControllerBase
    {
        // GET: api/<DesafioUmController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<DesafioUmController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<DesafioUmController>
        [HttpPost]        
        public void Post(Object json)
        {            
            try
            {
                string _json = json.ToString();
                dynamic dobj = JsonConvert.DeserializeObject<dynamic>(_json);
                int[] _itens = new int[dobj["itens"].Count];
                int _count = 0;
                bool _deveComprar = dobj["deveComprar"].Value;
                int _lucroEsperado = Convert.ToInt32(dobj["lucroEsperado"].Value);

                foreach (int itens in dobj["itens"])
                {
                    _itens[_count] = itens;
                    _count++;
                    Console.WriteLine(itens);
                }

                new DesafioBackend().Desafio03(_itens, _deveComprar, _lucroEsperado);

            }
            catch (Exception)
            {

                throw;
            }
        }

        // PUT api/<DesafioUmController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<DesafioUmController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
