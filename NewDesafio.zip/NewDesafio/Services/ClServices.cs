﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace NewDesafio.Services
{
    public class DesafioBackend
    {
        
        [Theory]
        [InlineData(new[] { 2, 7, 11, 15 }, true)]
        [InlineData(new[] { 1, 5, 4, 8 }, true)]
        [InlineData(new[] { 1, 9, 12, 25 }, false)]        
        public string Desafio01(int[] itens, bool hasMatch)
        {
            var result = Answers.FindTwoSum(itens, 9);

            if (result != null)
                Assert.True((itens[result.Item1] + itens[result.Item2] == 9) == hasMatch);
            else
                Assert.True((result is null) == !hasMatch);

            return result.ToString();
        }
                
        [Theory]
        [InlineData("{[()]}", true)]
        [InlineData("{[(])}", false)]
        [InlineData("{{[[(())]]}}", true)]
        public void Desafio02(string brackets, bool expeted)
        {
            Assert.Equal(Answers.FindPathernBracets(brackets), expeted);
        }

        
        [Theory]
        [InlineData(new[] { 7, 1, 5, 3, 6, 4 }, true, 5)]
        [InlineData(new[] { 7, 6, 4, 3, 1 }, false, 0)]
        public void Desafio03(int[] itens, bool deveComprar, int lucroEsperado)
        {
            int lucro;
            bool compra;

            itens = Answers.CompraAcao(itens, out lucro, out compra);

            Assert.Equal(lucro, lucroEsperado);

            Assert.Equal(compra, deveComprar);
        }


                
        [Theory]
        [InlineData(new[] { 0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1 }, 6)]
        public void Desafio04(int[] itens, int target)
        {
            Assert.Equal(target, Answers.WaterVolume2D(itens));
        }

    }

    internal class Answers
    {
        public static Tuple<int, int> FindTwoSum(IList<int> list, int sum)
        {
            var lookup = list.Select((x, i) => new { Index = i, Value = x })
                             .ToLookup(x => x.Value, x => x.Index);
            for (int i = 0; i < list.Count; i++)
            {
                int diff = sum - list[i];
                if (lookup.Contains(diff))
                    return Tuple.Create(i, lookup[diff].First());
            }

            return null;
        }

        public static bool FindPathernBracets(string expression)
        {

            Stack<string> stack = new Stack<string>();
            string[] splitExpression = expression.ToCharArray().Select(s => s.ToString()).ToArray();

            if (string.IsNullOrEmpty(expression))
            {
                return false;
            }

            for (int i = 0; i < splitExpression.Length; i++)
            {
                string caracter = splitExpression[i];
                if (caracter.Equals("(") || caracter.Equals("{") || caracter.Equals("["))
                {
                    stack.Push(caracter.ToString());
                    continue;
                }

                string lastCaracter = null;
                switch (caracter)
                {
                    case ")":
                        lastCaracter = (stack.Any() ? stack.Pop() : null);
                        if (string.IsNullOrEmpty(lastCaracter) || lastCaracter.Equals("{") || lastCaracter.Equals("["))
                        {
                            return false;
                        }
                        break;

                    case "}":
                        lastCaracter = (stack.Any() ? stack.Pop() : null);
                        if (string.IsNullOrEmpty(lastCaracter) || lastCaracter.Equals("(") || lastCaracter.Equals("["))
                        {
                            return false;
                        }
                        break;

                    case "]":
                        lastCaracter = (stack.Any() ? stack.Pop() : null);
                        if (string.IsNullOrEmpty(lastCaracter) || lastCaracter.Equals("{") || lastCaracter.Equals("("))
                        {
                            return false;
                        }
                        break;
                }
            }

            return !stack.Any();
        }

        public static int WaterVolume2D(int[] chuva)
        {
            int n = chuva.Length;
            int[] maisEsquerda = new int[n], maisDireita = new int[n];

            //varredura exclusiva esquerda, O (n), a barra mais alta à esquerda de cada ponto
            int maiorEsquerdoAtual = 0;
            for (int i = 0; i < n; i++)
            {
                maisEsquerda[i] = maiorEsquerdoAtual;
                if (chuva[i] > maiorEsquerdoAtual) maiorEsquerdoAtual = chuva[i];
            }


            // varredura exclusiva à direita, O (n), a barra mais alta à direita de cada ponto
            int maiorDireitodoAtual = 0;
            for (int i = n - 1; i >= 0; i--)
            {
                maisDireita[i] = maiorDireitodoAtual;
                if (chuva[i] > maiorDireitodoAtual) maiorDireitodoAtual = chuva[i];
            }

            // somatório
            int volume = 0;
            for (int i = 0; i < n; i++)
            {
                volume += Math.Max(0, Math.Min(maisEsquerda[i], maisDireita[i]) - chuva[i]);
            }
            return volume;
        }

        public static int[] CompraAcao(int[] itens, out int lucro, out bool compra)
        {
            do
            {
                if (Array.IndexOf(itens, itens.Max()) < Array.IndexOf(itens, itens.Min()))
                {
                    int numIndex = Array.IndexOf(itens, itens.Max());
                    itens = itens.Where((val, idx) => idx != numIndex).ToArray();
                }
            } while (Array.IndexOf(itens, itens.Max()) < Array.IndexOf(itens, itens.Min()));


            lucro = 0;
            compra = false;
            if (Array.IndexOf(itens, itens.Max()) > Array.IndexOf(itens, itens.Min()))
            {
                compra = true;
                lucro = itens.Max() - itens.Min();
            }

            return itens;
        }

    }
}